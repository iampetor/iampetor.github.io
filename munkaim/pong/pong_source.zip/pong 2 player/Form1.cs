﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Made by: Zagyvai Péter

namespace pong_2_player
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //UI start
            label1.Hide();
            label2.Hide();
            label7.Text = "ToString start the game press the Start Game button \r\nTo Exit the game press the Exit Game button \r\nTo come back to the main menu while playing press the ESC button on your keyboard \r\n \r\nControls: \r\nW,S for the player on the LEFT \r\nUP and DOWN arrows for the player on the RIGHT";
        }


        //declaration
        bool gameRunning = false;
        int fVelX, fVelY;
        //detects if the player wants to go up or down
        int player1movement = 0; 
        int player2movement = 0;
        //sets players' width (depends on game difficulty)
        int playerWidth;

        int playerSpeed = 5;
        int player1Score = 0;
        int player2Score = 0;
        int maxScore =5;
        //balls max speed
        int maxSpeed;
        //sets the players' name if textbox was empty
        string sPlayer1 = "Player1";
        string sPlayer2 = "Player2";

        //rectangles
        Rectangle player1;
        Rectangle player2;
        Rectangle ball;
        Rectangle background;

        //brushes
        SolidBrush brushPlayers;
        SolidBrush brushBall;
        SolidBrush brushBackground = new SolidBrush(Color.Black);

        //random
        Random rnd = new Random();

        //ButtonStart
        private void button1_Click(object sender, EventArgs e)
        {
            //Gets a maximum score (by default it's 5)
            if (textBox1.Text != "")
            {
                maxScore = Math.Min(int.Parse(textBox1.Text), 30);
            }
            //UI update
            label1.Show();
            label2.Show();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            label6.Hide();
            label7.Hide();
            button1.Enabled = false;
            button1.Hide();
            button2.Enabled = false;
            button2.Hide();
            textBox1.Enabled = false;
            textBox1.Hide();
            textBox2.Enabled = false;
            textBox2.Hide();
            textBox3.Enabled = false;
            textBox3.Hide();
            radioButton1.Enabled = false;
            radioButton1.Hide();
            radioButton2.Enabled = false;
            radioButton2.Hide();
            radioButton3.Enabled = false;
            radioButton3.Hide();
            //Player Options
            if (textBox2.Text != "")
            {
                sPlayer1 = textBox2.Text;
            }
            if (textBox3.Text != "")
            {
                sPlayer2 = textBox3.Text;
            }
            //Difficulty options
            if (radioButton1.Checked == true)
            {
                maxSpeed = 10;
                playerWidth = 100;
            }
            else if (radioButton2.Checked == true)
            {
                maxSpeed = 12;
                playerWidth = 90;
            }
            else if (radioButton3.Checked == true)
            {
                maxSpeed = 13;
                playerWidth = 80;
            }
            //starts game
            GameStart();
        }

        //Exits game
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Graphics
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (gameRunning == true)
            {
                e.Graphics.FillRectangle(brushBackground, background);                                  //background
                e.Graphics.FillRectangle(brushPlayers, player1);                                        //player1
                e.Graphics.FillRectangle(brushPlayers, player2);                                        //player2
                e.Graphics.FillEllipse(brushBall, ball);                                                //ball
                e.Graphics.FillRectangle(brushBall, ClientSize.Width / 2 - 2, 0, 4, ClientSize.Height); //midle line;
            }
            else
            {
                e.Graphics.Clear(Control.DefaultBackColor);
            }
        }

        
        //KeyDown
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //player1 movement
            if (e.KeyCode == Keys.W)
            {
                player1movement = 1;
            }
            else if (e.KeyCode == Keys.S)
            {
                player1movement = -1;
            }

            //player2 movement
            if (e.KeyCode == Keys.Up)
            {
                player2movement = 1;
            }
            else if (e.KeyCode == Keys.Down)
            {
                player2movement = -1;
            }

            if (e.KeyCode == Keys.Escape)
            {
                BackToMainMenu();
            }

            this.Invalidate();
        }


        //KeyUp
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.S)
            {
                player1movement = 0;
            }
            if(e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                player2movement = 0;
            }
        }

        //New game method
        void GameStart()
        {
            background = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
            brushPlayers = new SolidBrush(Color.White);
            brushBall = new SolidBrush(Color.White);
            ball = new Rectangle(ClientSize.Width / 2, ClientSize.Height / 2, 10, 10);
            player1 = new Rectangle(10, ClientSize.Height / 2, 20, playerWidth);
            player2 = new Rectangle(ClientSize.Width - 30, ClientSize.Height / 2, 20, playerWidth);

            gameRunning = true;

            timer1.Enabled = true;
            timer1.Interval = 1;

            //ball starting velocity
            int iRandomStart = rnd.Next(1, 5);
            if (iRandomStart == 1)
            {
                fVelX = rnd.Next(2, 6);
                fVelY = rnd.Next(2, 6);
            }
            if (iRandomStart == 2)
            {
                fVelX = rnd.Next(-5, -1);
                fVelY = rnd.Next(-5, -1);
            }
            if (iRandomStart == 3)
            {
                fVelX = rnd.Next(2, 6);
                fVelY = rnd.Next(-5, -1);
            }
            if (iRandomStart == 4)
            {
                fVelX = rnd.Next(-5, -1);
                fVelY = rnd.Next(2, 6);
            }

            //label positions
            label1.Left = ClientSize.Width/2 - 40;
            label1.Top = 10;
            label1.Text = player1Score.ToString();
            label2.Left = ClientSize.Width/2 + 10;
            label2.Top = 10;
            label2.Text = player2Score.ToString();


            this.Invalidate();
        }

        //Takes back to maun menu
        void BackToMainMenu()
        {
            //Game management settings
            gameRunning = false;
            timer1.Enabled = false;
            //UI settings
            label1.Hide();
            label2.Hide();
            label3.Show();
            label4.Show();
            label5.Show();
            label6.Show();
            label7.Show();
            button1.Enabled = true;
            button1.Show();
            button2.Enabled = true;
            button2.Show();
            textBox1.Enabled = true;
            textBox1.Show();
            textBox2.Enabled = true;
            textBox2.Show();
            textBox3.Enabled = true;
            textBox3.Show();
            radioButton1.Enabled = true;
            radioButton1.Show();
            radioButton2.Enabled = true;
            radioButton2.Show();
            radioButton3.Enabled = true;
            radioButton3.Show();
            //setting the default settings
            sPlayer1 = "";
            sPlayer2 = "";
            player1Score = 0;
            player2Score = 0;
            maxScore = 5;
        }

        


        //movement
        private void timer1_Tick(object sender, EventArgs e)
        {
                //player1 movement
            if (player1movement == 1)
            {
                player1.Y += -playerSpeed;
            }
            else if (player1movement == -1)
            {
                player1.Y += playerSpeed;
            }
            player1.Y = (Math.Min(player1.Y, ClientSize.Height-playerWidth));
            player1.Y = Math.Max(player1.Y, 0);


                //player2 movement
            if (player2movement == 1)
            {
                player2.Y += -playerSpeed;
            }
            else if (player2movement == -1)
            {
                player2.Y += playerSpeed;
            }
            player2.Y = (Math.Min(player2.Y, ClientSize.Height - playerWidth));
            player2.Y = Math.Max(player2.Y, 0);

                //ballmovement
            ball.X += fVelX;
            ball.Y += fVelY;

            //Oncolision
                //collision with borders
            if (ball.Top < 0)
            {
                fVelY = -fVelY;
            }
            if (ball.Bottom > ClientSize.Height)
            {
                fVelY = -fVelY;
            }

                //collision with player
            if (player1.IntersectsWith(ball))
            {
                fVelX = Math.Min(Math.Abs(fVelX*2), maxSpeed);
                ball.X = player1.X + 20;
            }
            if (player2.IntersectsWith(ball))
            {
                fVelX = -Math.Min(Math.Abs(fVelX*2), maxSpeed);
                ball.X = player2.X -10;
            }
         
            //Scores

            if (ball.Right < 0 && gameRunning== true)
            {
                player2Score++;
                GameStart();
            }
            if (ball.Left > ClientSize.Width && gameRunning == true)
            {
                player1Score++;
                GameStart();
            }

            //Game management
            if (player1Score == maxScore)
            {
                gameRunning = false;
                timer1.Enabled = false;
                MessageBox.Show(sPlayer1 + " won the game", "Winner Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            if (player2Score == maxScore)
            {
                gameRunning = false;
                timer1.Enabled = false;
                MessageBox.Show(sPlayer2 + " won the game", "Winner Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }

            this.Invalidate();
        }
    }
}
