﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace _2_zh_proba
{
    class Obsticles
    {
        public static Random rnd = new Random();
        Rectangle recObsticles;
        SolidBrush ecsetObsticles = new SolidBrush(Color.DimGray);
        int iSebX = 10;

        public Obsticles(int iSzel, int iMag)
        {
            int iRnd = rnd.Next(0, 4);

            if (rnd.Next(0,4) != 1)
            {
                recObsticles = new Rectangle(iSzel, iMag - 90, 40, 40);
            }
            else if (rnd.Next(4,6) != 4)
            {
                recObsticles = new Rectangle(iSzel, iMag - 110, 40, 40);
            }
            else if(rnd.Next(7, 10) != 7)
            {
                recObsticles = new Rectangle(iSzel, iMag - 130, 40, 40);
            }
            else
            {
                recObsticles = new Rectangle(iSzel, iMag - 90, 60, 40);
            }
        }

        public void Mozgat()
        {
            recObsticles.X -= iSebX;
        }

        public void Kirajzol(Graphics rajzlap)
        {
            rajzlap.FillRectangle(ecsetObsticles, recObsticles);
        }

        public bool PlayerUtkozes(Rectangle mivel)
        {
            if (recObsticles.IntersectsWith(mivel))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool FalUtkozes()
        {
            if (recObsticles.Right < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
