﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_zh_proba
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "0";
        }

        //Szamlalo
        int iElteltIdo;
        int iDifficultySzamlalo;


        //Jatekos
        Rectangle recPlayer;
        SolidBrush ecsetPlayer = new SolidBrush(Color.White);

        int iSebY = 0;
        bool bUgrik = false;

        //Platform
        Rectangle recPlatform;
        SolidBrush ecsetPlatform = new SolidBrush(Color.DimGray);

        //Obsticles
        List<Obsticles> obsticles;

        void UjJatek()
        {
            timer1.Interval = 1;
            timer2.Interval = 40;
            timer3.Interval = 4000;
            timer4.Interval = 1000;
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer4.Enabled = true;

            iElteltIdo = 0;
            iDifficultySzamlalo = 0;

            recPlayer = new Rectangle(50, ClientSize.Height-80, 20, 30);

            recPlatform = new Rectangle(0, ClientSize.Height - 50, ClientSize.Width, 50);

            obsticles = new List<Obsticles>();
            obsticles.Add(new Obsticles(ClientSize.Width, ClientSize.Height));

            this.Invalidate();
        }



        void JatekVege()
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
            timer3.Enabled = false;
            timer4.Enabled = false;
            
        }

        void Gugol()
        {
            Rectangle recPlayerCrouch = new Rectangle(recPlayer.X, recPlayer.Y + 15, 40, 15);
            recPlayer = recPlayerCrouch;
            if (bUgrik)
            {
                iSebY -= 5;
            }
            if (recPlayer.Bottom > ClientSize.Height - 50)
            {
                recPlayer.Y = ClientSize.Height - 65;
            }
        }

        void GugolVege()
        {
            Rectangle recPlayerOriginal = new Rectangle(recPlayer.X, recPlayer.Y - 15, 20, 30);
            recPlayer = recPlayerOriginal;
        }


        //Gomb bevitel

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Application.Exit();
            }

            if (e.KeyCode == Keys.Space)
            {
                UjJatek();
            }

            if (bUgrik == false)
            {
                if (e.KeyCode == Keys.W)
                {
                    bUgrik = true;
                    iSebY = 7;
                }
            }

            //gugolás
            if (e.KeyCode == Keys.S)
            {
                Gugol();
            }

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S)
            {
                GugolVege();
            }
        }

        //kirajzolás

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            if (timer1.Enabled)
            {
                e.Graphics.FillRectangle(ecsetPlatform, recPlatform);
                e.Graphics.FillRectangle(ecsetPlayer, recPlayer);
                foreach (Obsticles obstAkt in obsticles)
                {
                    obstAkt.Kirajzol(e.Graphics);
                }
            }
        }

        //mozgások és interakciók

        private void timer1_Tick(object sender, EventArgs e)
        {

            //ugrás inditas
            if (bUgrik)
            {
                recPlayer.Y -= iSebY;
            }


            //obsticle mozgatas
            foreach (Obsticles obstAkt in obsticles)
            {
                obstAkt.Mozgat();
            }


            //collision

            foreach (Obsticles obstAkt in obsticles)
            {
                if (obstAkt.PlayerUtkozes(recPlayer))
                {
                    JatekVege();
                }
            }

            for (int i = obsticles.Count()-1; i >= 0; i--)
            {
                if (obsticles[i].FalUtkozes())
                {
                    obsticles.RemoveAt(i);
                }
            }
            


                //ugras vege
            if (recPlayer.IntersectsWith(recPlatform))
            {
                iSebY = 0;
                bUgrik = false;
                recPlayer.Y--; //a játékos mindig a playtformban landolt, ezért emelek a pozicióján amíg fölé nem kerül
            }


            this.Invalidate();
        }

        //"gravitácó"

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (bUgrik)
            {
                iSebY--;
            }

            this.Invalidate();
        }

        //új akadályokat ad a játékba

        private void timer3_Tick(object sender, EventArgs e)
        {
            obsticles.Add(new Obsticles(ClientSize.Width, ClientSize.Height));
            this.Invalidate();
        }

        //eltelt időt növeli

        private void timer4_Tick(object sender, EventArgs e)
        {
            iElteltIdo++;
            iDifficultySzamlalo++;
            label1.Text = iElteltIdo.ToString();
            this.Invalidate();

            if (iDifficultySzamlalo == 20)
            {
                timer3.Interval = (int)(timer3.Interval * 2 / 3);
                iDifficultySzamlalo = 0;
            }
        }
    }
}
