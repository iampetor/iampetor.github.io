﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace pac_man_copy
{
    class Enemy
    {
        //declaration
        Rectangle enemyRec;
        SolidBrush enemyBrush;
        int iX, iY, width, height;
        

        public Enemy(int iXInput, int iYInput)
        {
            iX = iXInput;
            iY = iYInput;
            width = 16;
            height = 18;
            enemyRec = new Rectangle(iX, iY, width, height);
        }

        //GFX
        public void EnemyGFX(Graphics gfx, Color color)
        {
            enemyBrush = new SolidBrush(color);
            gfx.FillRectangle(enemyBrush, enemyRec);
        }
    }
}
