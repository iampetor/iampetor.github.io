﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace pac_man_copy
{
    class TileMap
    {
        //tileMap
        int[] iX, iY;
        Rectangle[,] tileMap;
        int distance;
        Pen tilemapBorder = new Pen(Color.DimGray, 1);
        int quantityX, quantityY;

        //mapFilling
        int clickX, clickY;
        SolidBrush fillingBrush = new SolidBrush(Color.DimGray);
        SolidBrush deletingBrush = new SolidBrush(Color.Red);
        int[,] filledRectangles;

        //Save Load
        string path = @"C:\Users\Péter\Desktop\Programing\Visual Studio\pac_man_copy_v0.3\pac_man_copy\Map\map_save";

        //Transfer
        List<Rectangle> wallToTranfer;

        public TileMap(int quantityXInput, int quantityYInput, int distanceInput)
        {

            quantityX = quantityXInput;
            quantityY = quantityYInput;

            filledRectangles = new int[quantityY, quantityX];

            MapLoading();

            distance = distanceInput;
            iX = new int[quantityX];
            iY = new int[quantityY];
            tileMap = new Rectangle[quantityY, quantityX];



            for (int i = 0; i < quantityX; i++)
            {
                iX[i] = i * distance;
            }
            for (int i = 0; i < quantityY; i++)
            {
                iY[i] = i * distance;
            }


            for (int i = 0; i < quantityY; i++)
            {
                for (int j = 0; j < quantityX; j++)
                {
                    tileMap[i, j] = new Rectangle(iX[j], iY[i], distance, distance);
                }
            }
        }


        //GFX
        public void Kirajzol(Graphics rajzlap)
        {
            for (int i = 0; i < quantityY; i++)
            {
                for (int j = 0; j < quantityX; j++)
                {
                    rajzlap.DrawRectangle(tilemapBorder, tileMap[i, j]);
                    if (filledRectangles[i, j] == 1)
                    {
                        rajzlap.FillRectangle(fillingBrush, tileMap[i, j]);
                    }
                    else if (filledRectangles[i, j] == 0)
                    {
                        rajzlap.FillRectangle(deletingBrush, tileMap[i, j]);
                    }
                    
                    rajzlap.DrawRectangle(tilemapBorder, tileMap[i, j]);
                }
            }
        }

        //Mouse input
        public void Filling(int eX, int eY)
        {
            clickX = eX / distance;
            clickY = eY / distance;
            filledRectangles[clickY, clickX] = 1;
        }
        public void Deleting(int eX, int eY)
        {
            clickX = eX / distance;
            clickY = eY / distance;
            filledRectangles[clickY, clickX] = 0;
        }
        

        //Saving
        public void Saving()
        {
            for (int i = 0; i < quantityY; i++)
            {
                string[] sTmpSaving = new string[quantityX];
                for (int j = 0; j < quantityX; j++)
                {
                    sTmpSaving[j] = filledRectangles[i, j].ToString();
                    File.WriteAllLines(path + i + ".txt", sTmpSaving, Encoding.UTF8);
                }
            }
        }


        //Loading
        void MapLoading()
        {
            for (int i = 0; i < quantityY; i++)
            {
                StreamReader sr = new StreamReader(path + i + ".txt");
                for (int j = 0; j < quantityX; j++)
                {
                        string sTmpLoad = sr.ReadLine();
                        filledRectangles[i, j] = int.Parse(sTmpLoad);
                }
                sr.Close();
            }
        }


        //wall transision
        public List<Rectangle> WallTrasfer(int quantityYInput, int quantityXInput)
        {
            wallToTranfer = new List<Rectangle>();
            for (int i = 0; i < quantityYInput; i++)
            {
                for (int j = 0; j < quantityX; j++)
                {
                    if (filledRectangles[i,j] == 1)
                    {
                        wallToTranfer.Add(tileMap[i, j]);
                    }
                }
            }
            return wallToTranfer;
        }
    }
}
