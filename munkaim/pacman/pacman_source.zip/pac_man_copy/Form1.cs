﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pac_man_copy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "";
        }

        //daclaration
        bool gameOn = false;
        Random rnd = new Random();
        int quantityY = 29;
        int quantityX =41;
        Point cursor;
        bool shiftOn = false;
        int newGameTimer;

        //Mega Coins
        Rectangle[] megaCoins;
        bool megaOn = false;
        int megaTimer;

        //Enemies
        Enemy[] enemies;
        Color[] enemyColor;

        //Coins
        Rectangle[,] coins;
        SolidBrush brushCoins = new SolidBrush(Color.White);
        int coinsX = 20;
        int coinsY = 20;
        int score = 0;
        int coinCount;

        //pac-man
        Rectangle recPacman;
        Rectangle pacmantop;
        Rectangle pacmanbot;
        Rectangle pacmanright;
        Rectangle pacmanleft;
        SolidBrush brushPacman = new SolidBrush(Color.Gold);
        int iSebX = 0;
        int iSebY = 0;

        //maze
        List<Rectangle> wall;
        SolidBrush brushWall = new SolidBrush(Color.DimGray);

        //TileMap
        bool tileMapOn = false;
        TileMap tileMap;

        //new game check
        Rectangle mapRactangle;
        Rectangle mapMiddleRectangle;
        Rectangle middleBarier;




        void NewGame()
        {
            //tileMap
            tileMap = new TileMap(quantityX, quantityY, 20);
            mapRactangle = new Rectangle(20, 60, ClientSize.Width-39, ClientSize.Height-80);
            mapMiddleRectangle = new Rectangle(380, 220, 60, 80);
            middleBarier = new Rectangle(400, 220, 20, 10);

            //enemies
            enemies = new Enemy[4];
            enemyColor = new Color[enemies.Count()];
            enemies[0] = new Enemy(382, 281);
            enemyColor[0] = Color.Blue;

            //megacoins
            megaCoins = new Rectangle[5];
            megaCoins[0] = new Rectangle(ClientSize.Width - 26, 6, 10, 10);
            megaCoins[1] = new Rectangle(15, 64, 10, 10);
            megaTimer = 0;


            //pacman
            iSebX = 0;
            iSebY = 0;
            recPacman = new Rectangle(ClientSize.Width / 2 - 7, ClientSize.Height - 36, 16, 16);
            pacmantop = new Rectangle(recPacman.X + 7, recPacman.Y - 2, 1, 1);
            pacmanbot = new Rectangle(recPacman.X +7, recPacman.Y + 15, 1, 1);
            pacmanright = new Rectangle(recPacman.X, recPacman.Y - 2, 1, 1);
            pacmantop = new Rectangle(recPacman.X, recPacman.Y + 17, 1, 1);

            //maze
            wall = new List<Rectangle>();
            wall = tileMap.WallTrasfer(quantityY,  quantityX);


            //Coins
            coins = new Rectangle[39, 21];
            for (int i = 0; i < 39; i++)
            {
                for (int j = 0; j < 21; j++)
                {
                    //placing the coins
                    coins[i, j] = new Rectangle(28 + i * (coinsX), 68  + j * coinsY, 4, 4);
                    foreach (Rectangle megaCur in megaCoins)
                    {
                        if (coins[i,j].IntersectsWith(megaCur))
                        {
                            coins[i, j] = new Rectangle(0, 0, 0, 0);
                        }
                    }
                    //deleting the coins that aren't needed
                    foreach (Rectangle wallCur in wall)
                    {
                        if (coins[i,j].IntersectsWith(wallCur) || coins[i,j].IntersectsWith(mapMiddleRectangle))
                        {
                            coins[i, j] = new Rectangle(0, 0, 0, 0);
                        }
                    }
                    if (coins[i,j].IntersectsWith(mapRactangle))
                    {
                        coinCount++;
                    }
                }
            }



            //game management
            gameOn = true;
            timer1.Interval = 1;
            timer1.Enabled = true;
            timer2.Interval = 125;
            newGameTimer = 0;

            this.Invalidate();
        }

        void GameOver()
        {
            gameOn = false;
            timer1.Enabled = false;
            MessageBox.Show("GAME OVER" + "\r\n" + "Your score is: " + score, "GAME OVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        
        //Inputs

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //Movement

                if (e.KeyCode == Keys.W)
                {
                    iSebY = -2;
                    iSebX = 0;
                }

                if (e.KeyCode == Keys.S)
                {
                    iSebY = 2;
                    iSebX = 0;
                }

                if (e.KeyCode == Keys.D)
                {
                    iSebX = 2;
                    iSebY = 0;

                }

                if (e.KeyCode == Keys.A)
                {
                    iSebX = -2;
                    iSebY = 0;
                }


            //Game Management
            if (e.KeyCode == Keys.Escape)
            {
                /*
                if (gameOn)
                {
                    tileMap.Saving();
                }
                */
                Application.Exit();
            }
            if (e.KeyCode == Keys.Space)
            {
                NewGame();
            }
            if (e.KeyCode == Keys.G)
            {
                if (tileMapOn)
                {
                    tileMapOn = false;
                }
                else
                {
                    tileMapOn = true;
                }
            }
            //tilemap saving
            if (e.KeyCode == Keys.F1)
            {
                tileMap.Saving();
                wall = new List<Rectangle>();
                wall = tileMap.WallTrasfer(quantityY,quantityX);
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (tileMapOn)
            {
                if (e.Button == MouseButtons.Left)
                {
                    tileMap.Filling(e.X, e.Y);
                }

                if (e.Button == MouseButtons.Right)
                {
                    tileMap.Deleting(e.X, e.Y);
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (gameOn)
            {
                //middle barrier
                e.Graphics.FillRectangle(new SolidBrush(Color.Black ), middleBarier);
                
                //maze
                foreach (Rectangle wallCur in wall)
                {
                    e.Graphics.FillRectangle(brushWall, wallCur);
                }

                //tilemap
                if (tileMapOn)
                {
                    tileMap.Kirajzol(e.Graphics);
                }

                //pacman
                e.Graphics.FillEllipse(brushPacman, recPacman);

                //coins
                for (int i = 0; i < 39; i++)
                {
                    for (int j = 0; j < 21; j++)
                    {
                        e.Graphics.FillEllipse(brushCoins, coins[i, j]);
                    }
                }

                //Mega Coins
                foreach (Rectangle megaCur in megaCoins)
                {
                    e.Graphics.FillEllipse(brushCoins, megaCur);
                }

                //enemies
                for (int i = 0; i < enemies.Count(); i++)
                {
                    if (enemies[i] != null)
                    {
                        enemies[i].EnemyGFX(e.Graphics, enemyColor[i]);
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cursor = PointToClient(Cursor.Position);

            label2.Text = cursor.X + ", " + cursor.Y + "\r\n" +
                         newGameTimer + "\r\n" + 
                         coinCount;

            //Movement
            //Player Movement
            recPacman.X += iSebX;
            recPacman.Y += iSebY;
            pacmantop.X = recPacman.X + 7;
            pacmantop.Y = recPacman.Y -2;
            pacmanbot.X = recPacman.X + 7;
            pacmanbot.Y = recPacman.Y + 17;
            pacmanleft.X = recPacman.X - 2;
            pacmanleft.Y = recPacman.Y + 7;
            pacmanright.X = recPacman.X + 16;
            pacmanright.Y = recPacman.Y + 7;

                //Enemy Movement
            


            //Collision
                //player Collision With Walls
            foreach (Rectangle wallCur in wall)
            {
                if (wallCur.IntersectsWith(pacmantop))
                {
                    iSebY = 0;
                    recPacman.Y++;
                }
                if (wallCur.IntersectsWith(pacmanbot))
                {
                    iSebY = 0;
                    recPacman.Y--;
                }
                if (wallCur.IntersectsWith(pacmanleft))
                {
                    iSebX = 0;
                    recPacman.X++;
                }
                if (wallCur.IntersectsWith(pacmanright))
                {
                    iSebX = 0;
                    recPacman.X--;
                }
            }

            if (mapMiddleRectangle.IntersectsWith(pacmanbot))
            {
                iSebY = 0;
                recPacman.Y--;
            }


                //Player Collision With Coins
            for (int i = 0; i < 39; i++)
            {
                for (int j = 0; j < 21; j++)
                {
                    if (recPacman.IntersectsWith(coins[i,j]))
                    {
                        coins[i, j] = new Rectangle(0,0,0,0);
                        score += 10;
                        coinCount--;
                    }
                }
            }

                //Player switching sides if goes out
            if (recPacman.Right < 0)
            {
                recPacman.X = ClientSize.Width - 1;
            }
            if (recPacman.Left > ClientSize.Width)
            {
                recPacman.X = -15;
            }
            
                //Enemy collision with wall


            //Mega Coins
            for (int i = 0; i < 5; i++)
            {
                if (recPacman.IntersectsWith(megaCoins[i]))
                {
                    megaOn = true;
                    megaTimer = 0;
                    megaCoins[i] = new Rectangle(0, 0, 0, 0);
                    timer2.Enabled = true;
                }
            }
            if (megaOn)
            {
                megaTimer++;
                brushPacman = new SolidBrush(Color.Blue);
            }
            if (megaTimer >= 500)
            {
                megaOn = false;
                megaTimer = 0;
                brushPacman = new SolidBrush(Color.Gold);
            }

            //new game mechanism
            if (coinCount == 0)
            {
                newGameTimer++;
                if (newGameTimer == 80)
                {
                    NewGame();
                }
            }

            //Score 
            label1.Text = "Score: " + score.ToString();

            this.Invalidate();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {


            timer2.Enabled = false;
        }

       
    }
}
